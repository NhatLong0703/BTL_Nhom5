const roomLst = [
    {
        name: "DeLaSea Ha Long Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room1.png"
    },
    {
        name: "FLC Halong Bay Golf Club & Luxury Resort",
        rate: "5.0 (128 Đánh giá)",
        image: "room2.png"
    },
    {
        name: "The Secret Ha Long Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room3.png"
    },
    {
        name: "Wyndham Legend Halong Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room4.png"
    },
    {
        name: "A La Carte Hạ Long",
        rate: "5.0 (128 Đánh giá)",
        image: "room5.png"
    },
    {
        name: "Halios Hotel Halong",
        rate: "5.0 (128 Đánh giá)",
        image: "room6.png"
    },
    {
        name: "Thai Ha Boutique Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room7.png"
    },
    {
        name: "Citadines Marina Hạ Long",
        rate: "5.0 (128 Đánh giá)",
        image: "room8.png"
    },
    {
        name: "Wyndham Garden Legend Ha Long",
        rate: "5.0 (128 Đánh giá)",
        image: "room9.png"
    },
]

const roomContainer = document.getElementById("room-list");

roomLst.forEach(room => {
    const roomHTML = `
    <div class="bg-white shadow rounded-[20px] overflow-hidden pb-[20px] transition-all transform duration-300 hover:-translate-y-2 hover:shadow-lg">
      <a href="">
        <img src="/assets/image/${room.image}" alt="${room.name}" class="w-full h-48 object-cover" />
        <div class="p-[20px]">
          <h3 class="text-[26px] font-bold mb-1 text-[#000]">${room.name}</h3>
          <p class="text-[16px] text-[#000] mb-2 flex items-center gap-2">
            <svg
            width="20"
            height="20"
            viewBox="0 0 17 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
            >
            <rect
                x="0.904419"
                y="0.0130005"
                width="15.1385"
                height="15.1385"
                fill="url(#pattern0_18_37)"
            />
            <defs>
                <pattern
                id="pattern0_18_37"
                patternContentUnits="objectBoundingBox"
                width="1"
                height="1"
                >
                <use
                    xlink:href="#image0_18_37"
                    transform="scale(0.0104167)"
                />
                </pattern>
                <image
                id="image0_18_37"
                width="96"
                height="96"
                preserveAspectRatio="none"
                xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAHkElEQVR4Xu1di3EbNxA9ugK7gsgVxK4gcgUR1YDlCmJXEKsCpwPLDdjqIEoFZioIO4jSgJhdAJRPJA+7wD58buZuRkPPGCAO+3bffrB3XA3L1VQCq6arL4sPCwCNlWABYAGgsQQaL79YwAJAYwk0Xn6xgAWAuAR2F8NzGvHK/T0bfqLP58NuOHOfg/vk657iuY375L+H4T/63Kxuh9vG8hWX79ICSOgs8HMS6tsgZBZ23rUiEB6Gv2nyLQHCIHV1dQNA0PT3JPRfg8aXEBRbys3q6/ChxJfnfGdzAILgr0gwv40oJWcvKXPuicY+kEXcpEwqMbYZAEHwTDOfKgr+UIbNgWgCAAn/jBzqJ9LCixJalfGdG7qXNVnENmOuaUp1AEj4rPXf6K7zHatpy5OT2Rre1Y6cqgJAwv8YuL434f9AZTdcEwgfy2B8/K1VAHB8/2z4bKAcjl7uKJz8i7bAsT5Txf6Td7XPFfjfTG8/01pXBiHeBUriNYpexQEwCH9LQvhCu+dkaktamSwMWpt9zKtRPpEizM3q2/A6ZULO2PIAXBLfpzlb5uJr2sxNjtCnhEBgcI6RGureEQhvcgSrnVMUgN2li3TeK2+miOAP1w5AcOiruyiTpsRtrRucPqoYAIkbrRoGOlpcDX86etJcPmn7QzM0dUwRAGiDnNmylmminWoO78gaUujR5wnw4h4cgKBd3100Il0r0qoHF/YlO1jpq7X/H0Lj3xXjmSJfou+1BAAc68sbIuH3UhRT+6oC9wwFIGj/PyL1+BIxZ53NND+TjtgKXiNLFmgANNrPDvdNT8JnMNSO2Zez3ykoSzUEBoArsK0G5v6Y42UNYuF3dzAyAkG2YO8LtioJC4NwAGhi/sp1lhwBqZwy0ApwAKwH1pxY5FMkisgRcmyOMoq7pwz5BWJtCADuDNfTz/Q1A+3f33zIYz4L+2FnbKZSFABcZ4ml97PQ/hEAnCnHcxlQdowBQMooC8TPCPOPGqzs07ZEQy+t92EGQBX7A9P40LJyQRr6S4i4WFs3ofWEK6iQ6MSVsv3JXYxWzdEQAoAqNxrCRLnGBKKGoFj/CgBwMnljsQIEABL/Qw42qFyQcq4AqePv1q5iej4pYEBggQAgnv0C+D+xtO3lBbAEMScA7M0OwKU7672KaInJTJUZ9unlfd0mO1QU/QDgsAYBQJwajA44S/sf40lbh0NooWEamrrMVGcHQOZJrv3c5TqqRO5/uoxRQ4P1cYY/dZlDUQQA8RKEsXBFjlAqccSwNZUMFJGQ6fv5xhcABNMkBdjFhlAyZpKhabILNtYDx8rTJejd8MJS+zdR0DCYOXoOAHDNZLq7wB6JaA55TiupMUxUFBm78AFSsmJzwv6gJ+YIpxiCC4DcyZAfAPhG4s6jIKlohUmIpGz7GARAliqWpQEHM3Yf4Duep7sgjKHgY0gvhbtjCECH/qL/MVIcJgqSq4bmUO0RBN/fKZ07XNN4SF+pGAIbk0wUAFwOlqqGJj8wVu6DcvQ5/R+3tmxCSfqLpfRwtI58yte+HB1C0bgjBphqbiadO08sxPFzyID2dbMPcABIfoC0FHWInSvQlHmqg3mQUqEA0NCQqSqaIkDrWLEK6rQO06wLASDQkFSzmY0ViAcx7HdAjbo4AHxLutTKUaTF26rxB85Xc8QKe5APCYBMQ/ysF6CTACnww+9Saj+sQRcGgKMhKSv23NmtL1Ad/gCy36c5I1CdFPVzXg3e4o3Ygqq9xiuQ6Zjz8F6hFhCsIH5GzIPAWgQCQK66gsoqxSwg5AQaX8CaBMuOrQCEsjMnk9Vb6+EWEECQtamT5Ez9YAagunpKUYoAoMwLmIqKPoOrsQxV4MCvRvDcD3+kqhwA8mGGlw8oo9QI+yjk1OQuhSO3YgAEh6xpJ2wSFakbvgpbaVkA/BPp8VK1V8uqCVrgfe58Phcsp/gzbUUBCA5ZTu29FMwdDFoaIt6XQ2VPPcVeUbC/1+IABCrSbRhU4o0Bocp2+Qsq3ItfptJFNZZ4+8r+Pgo6ZfGQ/Ycsqj3LXA+AlPYScLofqJAfJJSSLR5anPfHOl8NgER/ABWCMtP1cqnA+80ASPIHIE0M4SZr/pnItpV4vykADgR9j4/p5EldZvASqcb7zQEIIOiccmYZYA7CrxoFHZq/qvNgFJWktIC479a/JpPrPFyZ3YoUVWBAVSd8AgTNG1b201QUkSh8qLPPwacpAKPwMP6eiZElxN41lCF8Ph6FvwcuBYjmAAQQpDbw8Z5OloYTOb+bs+kuAMgEgVtc3COoSaGmm9BPY0A3AGSA4PjbmYZ/p8OZyvQ7En7TKGhKWIpnc8dT+YSK/2Yp/C4ByLAEleL3RDvjG+6KgsY3lmgJcRA6o51ZAACzhI6F3y0FgSyh+Q/0aLixWwo6AEF+KeDT3Tb5PRiNwA/HzAKAQEcMgibcND8fnCPI3DmzASCAIL33v+rvEOQKfTZO+NQGIy0lqmIdQmjI75iVBTzxC0/fIdfsRyCsYMwWAEdJ/EAIX41/BMICwqwBsGy8l7kLAI2RWABYAGgsgcbLLxawANBYAo2XXyxgAaCxBBov/z/j/EKO9PNcMQAAAABJRU5ErkJggg=="
                />
            </defs>
            </svg>
            Hạ Long
          </p>
          <div class="flex items-center text-sm text-yellow-500 space-x-1">
            <div class="flex text-yellow-400 text-sm">
              ${'<svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M10 15l-5.878 3.09 1.123-6.545L.49 6.91l6.574-.955L10 .5l2.936 5.455 6.574.955-4.755 4.635 1.123 6.545z"/></svg>'.repeat(5)}
            </div>
            <span class="text-[#000]">${room.rate}</span>
          </div>
        </div>
      </a>
    </div>
    `;
    roomContainer.innerHTML += roomHTML;
});