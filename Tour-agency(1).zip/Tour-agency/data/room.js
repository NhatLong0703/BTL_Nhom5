export const roomLst = [
    {
        name: "DeLaSea Ha Long Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room1.png"
    },
    {
        name: "FLC Halong Bay Golf Club & Luxury Resort",
        rate: "5.0 (128 Đánh giá)",
        image: "room2.png"
    },
    {
        name: "The Secret Ha Long Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room3.png"
    },
    {
        name: "Wyndham Legend Halong Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room4.png"
    },
    {
        name: "A La Carte Hạ Long",
        rate: "5.0 (128 Đánh giá)",
        image: "room5.png"
    },
    {
        name: "Halios Hotel Halong",
        rate: "5.0 (128 Đánh giá)",
        image: "room6.png"
    },
    {
        name: "Thai Ha Boutique Hotel",
        rate: "5.0 (128 Đánh giá)",
        image: "room7.png"
    },
    {
        name: "Citadines Marina Hạ Long",
        rate: "5.0 (128 Đánh giá)",
        image: "room8.png"
    },
    {
        name: "Wyndham Garden Legend Ha Long",
        rate: "5.0 (128 Đánh giá)",
        image: "room9.png"
    },
]